class SharedPreferenceConstants{
  static const USER_ID  = "user_id";
  static const NAME  = "name";
  static const EMAIL  = "email";
  static const PHONE  = "phone";
  static const PROFILE_PICTURE  = "profile_pic";
  static const VARIFICATION_ID  = "varification_id";
}
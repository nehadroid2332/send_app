import 'package:flutter/cupertino.dart';

class ApplicationConstants {

  //Color Strings for the app
  static const APP_RED_COLOR = Color(0xFFB71B1B);
  static const APP_GREEN_COLOR = Color(0xFF16813D);
  static const double APP_NORMAL_FONT_SIZE = 16;
  static const String APP_COUNTRY_CODE = "+91";
  static const String APP_CURRENCY = "₺";

  //App Constant String
  static const APP_NAME = "EvElleri";
}

import 'package:flutter/material.dart';
import 'package:sendapp/ui/login_page/login_page.dart';
import 'package:sendapp/utils/constants.dart';
import 'package:sendapp/utils/sharedPreferenceUtils.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: "futura",
          primaryColor: Constants.THEME_COLOR),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  SharedPreferences sharedPreferences;
  var id,otpVerified;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((SharedPreferences sp) {
      sharedPreferences = sp;
      id = sharedPreferences.getString(SharedPreferenceUtils.ID);
      otpVerified = sharedPreferences.getString(SharedPreferenceUtils.OTP_VARIFIED);
      print(otpVerified);
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: LoginPage());
  }
}

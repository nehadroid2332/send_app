class SharedPreferenceUtils{
  static var VARIFICATION_ID = "verificationId";
  static var ID = "id";
  static var UNIQUEHASH = "uniqueHash";
  static var USERIMAGE = "userimage";
  static var NAME = "name";
  static var CONTACTNUMBER = "contactNumber";
  static var EMAIL = "email";
  static var OTP_VARIFIED = "otp";
}
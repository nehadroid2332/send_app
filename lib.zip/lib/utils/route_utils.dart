
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RouteUtils{
  /*static homePage(BuildContext context){
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(),
        ),
        ModalRoute.withName("/Home"));
  }
  static loginPage(BuildContext context){
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => LoginPage(),
        ),
        ModalRoute.withName("/Home"));
  }*/
}
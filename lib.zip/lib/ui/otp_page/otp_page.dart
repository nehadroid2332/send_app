import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_input_text_field/pin_input_text_field.dart';
import 'package:sendapp/ui/card_page/card_page.dart';
import 'package:sendapp/utils/constants.dart';

class OtpPage extends StatefulWidget {
  final String userPhoneNumber, verifyOTP, firebaseToken;
  final bool isRegistered;

  OtpPage(
      {this.userPhoneNumber,
      this.verifyOTP,
      this.firebaseToken,
      this.isRegistered});

  @override
  State<StatefulWidget> createState() => OtpPageState();
}

class OtpPageState extends State<OtpPage> {
  static const TextStyle _textStyle = TextStyle(
    color: Colors.black,
    fontSize: 24,
  );
  PinDecoration _pinDecoration = UnderlineDecoration(
    textStyle: _textStyle,
    enteredColor: Colors.green,
  );
  TextEditingController _pinEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final _width = MediaQuery.of(context).size.width;
    final _height = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: _width,
              height: _height * .4,
              child: new Column(
                children: <Widget>[
                  new Expanded(
                    flex: 1,
                    child: new Container(
                      color: Constants.THEME_COLOR,
                      width: _width,
                      alignment: Alignment.center,
                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: _height * .06,
                          ),
                          Icon(
                            Icons.phone_iphone,
                            color: Colors.black,
                            size: 100,
                          ),
                          SizedBox(
                            height: _height * .03,
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              gradient: LinearGradient(
                                begin: FractionalOffset.topCenter,
                                end: FractionalOffset.bottomCenter,
                                colors: [
                                  Constants.THEME_COLOR.withOpacity(0.8),
                                  Constants.THEME_COLOR.withOpacity(0.8),
                                ],
                                stops: [0.0, 1.0],
                              ),
                            ),
                            child: Container(
                              child: Center(
                                child: Text(
                                  "OTP Verification",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ), //varaible above
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: _width,
              height: _height * .60,
              color: Constants.THEME_COLOR,
              child: Column(
                children: <Widget>[
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Constants.OTP_STRING,
                    style: TextStyle(fontSize: 18, color: Colors.black),
                  ),
                  SizedBox(height: 20,),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Container(
                      width: 200,
                      color: Colors.white,
                      child: TextField(
                        keyboardType: TextInputType.number,
                        controller: _pinEditingController,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(6),
                        ],
                        decoration: new InputDecoration(
                          fillColor: Colors.black,
                          labelText: "    Verification Code",
                          labelStyle: TextStyle(color: Colors.grey),
                          hintStyle: TextStyle(color: Colors.grey),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey),
                          ),
                        ),
                        cursorColor: Colors.grey,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: _height * .03,
                  ),
                  Text.rich(
                    TextSpan(text: "Don't get OTP?",style: TextStyle(color: Colors.black), children: <TextSpan>[
                      TextSpan(
                        text: " Resend OTP",
                        style: TextStyle(color: Colors.red),
                      )
                    ]),
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey),
                  ),
                  SizedBox(
                    height: _height * .07,
                  ),
                  SizedBox(
                    width: _width - 200,
                    height: 50,
                    child: RawMaterialButton(
                      onPressed: () {
                        verifyOTP();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            "Verify",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w800),
                          ),
                        ],
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(30))),
                      fillColor: Colors.black,
                      elevation: 6.0,
                      padding: const EdgeInsets.all(13.0),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void verifyOTP() async {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CardPage()),
    );
    if (_pinEditingController.text.isNotEmpty) {
    } else {
      //Fluttertoast.showToast(msg: "OTP can't be empty.");
    }
  }
}

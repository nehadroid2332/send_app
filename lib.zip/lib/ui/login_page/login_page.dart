import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';
import 'package:sendapp/ui/otp_page/otp_page.dart';
import 'package:sendapp/utils/constants.dart';

class LoginPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => LoginPageState();
}

class LoginPageState extends State<LoginPage> {
  TextEditingController phoneNumberController = new TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final _width = MediaQuery.of(context).size.width;
    final _height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: _width,
              height: _height * .5,
              child: new Column(
                children: <Widget>[
                  new Expanded(
                    flex: 1,
                    child: new Container(
                        color: Constants.THEME_COLOR,
                        width: _width,
                        alignment: Alignment.center,
                        child: Stack(
                          children: <Widget>[
                            Container(
                              height: _height * .6,
                              decoration: BoxDecoration(
                                color: Colors.black,
                                gradient: LinearGradient(
                                  begin: FractionalOffset.topCenter,
                                  end: FractionalOffset.bottomCenter,
                                  colors: [
                                    Constants.THEME_COLOR.withOpacity(0.8),
                                    Constants.THEME_COLOR.withOpacity(0.8),
                                  ],
                                  stops: [0.0, 1.0],
                                ),
                              ),
                              child: Container(
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      SizedBox(height: 40,),
                                      Text(
                                        Constants.APP_NAME1,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 40,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(height: 10,),
                                      Text(
                                        Constants.APP_NAME2,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ) //varaible above
                        ),
                  ),
                ],
              ),
            ),
            Container(
              width: _width,
              height: _height * .50,
              color: Constants.THEME_COLOR,
              child: Column(
                children: <Widget>[
                  SizedBox(
                    height: 60,
                  ),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Container(
                      width: _width - 100,
                      color: Colors.white,
                      child: TextField(
                        keyboardType: TextInputType.number,
                        controller: phoneNumberController,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(10),
                        ],
                        decoration: new InputDecoration(
                          fillColor: Colors.white,
                          labelText: "Mobile Number",
                          labelStyle: TextStyle(color: Colors.grey),
                          prefixIcon: Icon(
                            Icons.phone_iphone,
                            color: Colors.black,
                          ),
                          hintStyle: TextStyle(color: Colors.grey),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey),
                          ),
                        ),
                        cursorColor: Colors.grey,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  SizedBox(
                    width: _width - 100,
                    height: 50,
                    child: RawMaterialButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => OtpPage()),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            "Sign In",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w800),
                          ),
                        ],
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(30))),
                      fillColor: Colors.black,
                      elevation: 6.0,
                      padding: const EdgeInsets.all(13.0),
                    ),
                  ),
                  Spacer(),
                  Text.rich(
                    TextSpan(
                        text: "By Signing up, you are agree to out ",
                        children: <TextSpan>[
                          TextSpan(
                            text: "terms & conditions",
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                            ),
                          )
                        ]),
                    style: TextStyle(fontSize: 12, color: Colors.black),
                  ),
                  SizedBox(
                    height: 30,
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  bool isPhoneValid(String number) {
    String p = r'(^(?:[+0]9)?[0-9]{10,12}$)';

    RegExp regExp = new RegExp(p);

    return regExp.hasMatch(number);
  }
}

/*
* Converts json map to model objects by using the provided fromJson
* factory method of objects.
* */

import 'package:sendapp/data/models/api_response.dart';

T convertResponse<T>(dynamic data) {
  switch (T) {
    case LoginResponse:
      return LoginResponse.fromJson(data) as T;
    /*case ProfileResponse:
      return ProfileResponse.fromJson(data) as T;*/
  }

  throw Exception(
      "No response converter provided. Please provide a converter for ${T.runtimeType}");
}

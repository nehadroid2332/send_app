import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sendapp/constant/shared_preference_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PhoneAuth {
  SharedPreferences sp;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();
  String phoneNumber;
  String verificationId;

  Future<void> verifyPhone(BuildContext context, phoneNumber) async {
    sp = await SharedPreferences.getInstance();

    final PhoneCodeSent smsCodeSent = (String verId, [int forceCodeResend]) {
      this.verificationId = verId;
      sp.setString(SharedPreferenceConstants.VARIFICATION_ID, verId);
    };

    final PhoneVerificationCompleted verifiedSuccess = (dynamic user) {
      print('verified');
      print(user);
    };

    final PhoneVerificationFailed verifiedFailed = (AuthException exception) {
      print('${exception.message}');
    };

    await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        codeSent: smsCodeSent,
        timeout: Duration(seconds: 30),
        verificationCompleted: verifiedSuccess,
        verificationFailed: verifiedFailed);
  }

/*  verifyOTPSignIn(
      {BuildContext context,
      String smsCode,
      String number}) async {
    _showProgressDialog(context);
    sp = await SharedPreferences.getInstance();
    final AuthCredential credential = PhoneAuthProvider.getCredential(
      verificationId: sp.getString(SharedPreferenceConstants.VARIFICATION_ID),
      smsCode: smsCode,
    );
    try {
       await _auth.signInWithCredential(credential);
      UserRepository userRepository = new UserRepository();
      var loginResponse = await userRepository.registerUser(
          registerUserRequest: registerUserRequest);
      if (loginResponse != null) {
        RouteUtils.homePageRoute(context);
      }
    } catch (e) {
      Navigator.of(context).pop();
      Fluttertoast.showToast(
          msg: e.toString(),
          gravity: ToastGravity.BOTTOM,
          toastLength: Toast.LENGTH_LONG);
    }
  }*/

  void _showProgressDialog(BuildContext context) {
    showDialog<Null>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return new AlertDialog(
          content: new SingleChildScrollView(
            child: Container(
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: CircularProgressIndicator(),
                  ),
                  Text("Loading"),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

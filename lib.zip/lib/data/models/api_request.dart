import 'dart:io';

class LoginUserRequest {
  final String contactNumber;
  final String firebaseToken;

  LoginUserRequest({this.contactNumber, this.firebaseToken});
}

class RegisterUserRequest {
  final String name;
  final String email;

  RegisterUserRequest({this.name, this.email});
}

class SubCategoryRequest {
  final String categoryId;

  SubCategoryRequest({this.categoryId});
}

class ServiceRequest {
  final String subCategoryId;

  ServiceRequest({this.subCategoryId});
}

class ServiceDetailsRequest {
  final String serviceId;

  ServiceDetailsRequest({this.serviceId});
}

class AddAddressRequest {
  final String id;
  final String title;
  final String fullAddress;
  final String cityId;
  final String postalCode;
  final String isDefault;
  final String latitude;
  final String longitude;
  bool selected;

  AddAddressRequest(
      {this.title,
      this.id,
      this.fullAddress,
      this.cityId,
      this.postalCode,
      this.isDefault,
      this.selected,
      this.latitude,
      this.longitude});

  factory AddAddressRequest.fromJson(Map map) {
    return AddAddressRequest(
        title: map['title'],
        postalCode: map['postalCode'],
        id: map['id'],
        fullAddress: map['fullAddress']);
  }
}

class RemoveAddressRequest {
  final String addressId;

  RemoveAddressRequest({this.addressId});
}

class BookServiceRequest {
  final String serviceId;
  final String addressId;
  final String serviceDate;
  final String serviceTimeFrom;
  final String serviceTimeTo;

  BookServiceRequest(
      {this.serviceId,
      this.addressId,
      this.serviceDate,
      this.serviceTimeFrom,
      this.serviceTimeTo});
}

class UploadUserImageRequest {
  final File file;

  UploadUserImageRequest({this.file});
}

class ServiceRequestListRequest {
  final String status;

  ServiceRequestListRequest({this.status});
}

class SearchCategoryRequest {
  final String name;

  SearchCategoryRequest({this.name});
}

class SubmitRatingRequest {
  final String questionId;
  final String userComment;
  final String serviceId;

  SubmitRatingRequest({this.questionId, this.userComment, this.serviceId});
}

class GetStaticContentRequest{
  final String alias;

  GetStaticContentRequest({this.alias});

}

class LoginResponse {
  final String id;
  final String name;
  final String email;
  final String contactNumber;
  final String image;
  final String uniqueHash;
  final String verifyToken;
  final bool isRegistered;

  LoginResponse({
    this.id,
    this.name,
    this.email,
    this.contactNumber,
    this.image,
    this.verifyToken,
    this.uniqueHash,
    this.isRegistered,
  });

  factory LoginResponse.fromJson(Map map) {
    return LoginResponse(
        id: map['id'],
        name: map['name'],
        contactNumber: map['contactNumber'],
        email: map['email'],
        image: map['image'],
        verifyToken: map['verifyToken'],
        isRegistered: map['isRegistered'],
        uniqueHash: map['uniqueHash']);
  }
}

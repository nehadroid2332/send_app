import 'package:sendapp/data/converter/model_converter.dart';

class Response<T> {
  final bool success;
  final int status;
  final String message;
  final T data;

  Response({
    this.success,
    this.status,
    this.message,
    this.data,
  });

  factory Response.fromJson(Map map) {
    return Response(
      success: map["success"],
      status: map["status"],
      message: map["message"],
      data: map["data"] == null ? null : convertResponse<T>(map["data"]),
    );
  }

  factory Response.failed({String message, int status: 400}) {
    return Response(
      success: false,
      status: status,
      message: message,
      data: null,
    );
  }

  @override
  String toString() {
    return "${success}, ${status}, ${message}, ${data}";
  }
}

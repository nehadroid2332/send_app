import 'package:sendapp/data/models/api_request.dart';
import 'package:sendapp/data/models/api_response.dart';
import 'package:sendapp/data/models/response.dart';

abstract class NetworkApi {
  Future<Response<LoginResponse>> loginUser({
    LoginUserRequest loginUserRequest,
  });
}


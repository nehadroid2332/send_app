import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as dartHttp;
import 'package:sendapp/data/models/api_request.dart';
import 'package:sendapp/data/models/api_response.dart';
import 'package:sendapp/data/models/response.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'network_api.dart';

class NetworkApiImpl implements NetworkApi {
  //var BASE_URL = "http://quickquick.online/";
  static var BASE_URL = "https://aaramsey.com/";
  SharedPreferences sharedPreferences;
  var timeoutDuration = 30;

  @override
  Future<Response<LoginResponse>> loginUser(
      {LoginUserRequest loginUserRequest}) async {
    var completeURL = BASE_URL + "app_login";
    sharedPreferences = await SharedPreferences.getInstance();
    Map body;
    body = {
      "contactNumber": loginUserRequest.contactNumber,
      "firebaseToken": loginUserRequest.firebaseToken,
    };
    try {
      dartHttp.Response apiResponse = await dartHttp
          .post(
            completeURL,
            body: body,
          )
          .timeout(Duration(seconds: timeoutDuration));
      Map decodedBody = jsonDecode(apiResponse.body);
      print(decodedBody);
      if (decodedBody['status'] == 200) {
        LoginResponse loginResponse =
            LoginResponse.fromJson(decodedBody['data']);
        return Response(
          success: true,
          data: loginResponse,
          message: "Success",
          status: decodedBody["status"],
        );
      } else {
        print('Error occured!!!!!');
        return Response.failed(
          message: decodedBody["message"],
        );
      }
    } catch (e) {
      print(e);
      if (e is TimeoutException) {
        return Response.failed(
          message: "Network Timeout.",
        );
      } else {
        return Response.failed(
          message: "Error occured. Please check your network connection.",
        );
      }
    }
  }
}
